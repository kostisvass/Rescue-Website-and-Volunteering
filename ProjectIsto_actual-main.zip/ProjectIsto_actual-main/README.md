This a project for a class in university named Programming in the World Wide Web.
Developed in collaboration with [Dimitrios Baroutis](https://github.com/jimbaroutis) and Konstantinos Basiladiotis.

This website helps volunteer rescue personnel and citizens collaborate and meet the demands of supplying areas where natural disasters have struck.
